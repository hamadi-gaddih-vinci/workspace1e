const db = require('../models/db_conf');

module.exports.listExomoon = (exoplanet_id) => db.prepare('SELECT * FROM EXOMOONS WHERE exoplanet_id = ?').all(exoplanet_id);

module.exports.save = (data) => {
  const stmt = db.prepare('INSERT INTO EXOMOONS(unique_name, exoplanet_id) VALUES (?, ?)');
  const info = stmt.run(data.uniqueName, data.exoplanet_id);
  console.log("exomoon model save insert" + info.changes);
};


