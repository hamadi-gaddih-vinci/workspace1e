import java.util.*;
import java.io.*;

public class DequeVideException extends RuntimeException {
	   
    public DequeVideException() {
      super();
   }

    public DequeVideException(String s) {
      super(s);
   }

}
