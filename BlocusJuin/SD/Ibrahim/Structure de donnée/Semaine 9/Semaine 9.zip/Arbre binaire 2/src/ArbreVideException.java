
public class ArbreVideException extends RuntimeException {

	public ArbreVideException() {
		super();
	}

	public ArbreVideException(String message) {
		super(message);
	}

}
