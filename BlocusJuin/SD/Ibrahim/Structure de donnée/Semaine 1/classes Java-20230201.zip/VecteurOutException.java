
public class VecteurOutException extends RuntimeException {

		public VecteurOutException() {
			super();
		}

		public VecteurOutException(String message) {
			super(message);
		}

	}
