
public class DejaPresentException extends RuntimeException{

	public DejaPresentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DejaPresentException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}


}
