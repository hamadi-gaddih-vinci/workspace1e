
public class NonPresentException extends RuntimeException {
	
	public NonPresentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NonPresentException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
