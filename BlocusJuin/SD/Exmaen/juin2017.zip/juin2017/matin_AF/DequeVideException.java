
public class DequeVideException extends RuntimeException{
	
	public DequeVideException() {
		super();
	}

	public DequeVideException(String message) {
		super(message);
	}
}
