import java.util.ArrayList;

public class UnshuffleSort {
	
	// TODO

	public UnshuffleSort() {
		// TODO
	}

	// cfr enonce examen
	public void placerEntier(int entier) {
		// TODO
	}
	
	
	public String toString(){
		// TODO
		return null;
	}

}
