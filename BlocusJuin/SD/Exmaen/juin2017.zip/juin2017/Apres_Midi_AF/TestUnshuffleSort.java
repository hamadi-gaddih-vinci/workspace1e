
public class TestUnshuffleSort {

	public static void main(String[] args) {
		System.out.println("**********************************");
		System.out.println("Tests de la methode placerEntier()");
		System.out.println("********************************** ");
		UnshuffleSort u = new UnshuffleSort();
		System.out.println("placerEntier(3)");
		u.placerEntier(3);
		System.out.println(u);
		System.out.println();
		System.out.println("placerEntier(5)");
		u.placerEntier(5);
		System.out.println(u);
		System.out.println();
		System.out.println("placerEntier(2)");
		u.placerEntier(2);
		System.out.println(u);
		System.out.println();
		System.out.println("placerEntier(4)");
		u.placerEntier(4);
		System.out.println(u);
		System.out.println();
		System.out.println("placerEntier(8)");
		u.placerEntier(8);
		System.out.println(u);
		System.out.println();
		System.out.println("placerEntier(7)");
		u.placerEntier(7);
		System.out.println(u);
		System.out.println();
		System.out.println("placerEntier(6)");
		u.placerEntier(6);
		System.out.println(u);
		System.out.println();
		
	}
}
