import java.util.LinkedList;

//METTEZ VOTRE NOM ET VOTRE PRENOM!!!!

public class UnshuffleSort {
	
	// TODO

	public UnshuffleSort() {
		// TODO
	}

	// cfr enonce examen
	public void placerEntier(int entier) {
		// TODO
	}
	

	
	public String toString(){
		// TODO
		return null;
	}

}
