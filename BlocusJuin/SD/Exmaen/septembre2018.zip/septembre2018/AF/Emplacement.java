import java.time.LocalDate;


public class Emplacement {
	
	private int numeroEmplacement;
	private Vacancier vacancier;
	private LocalDate date;
	
	public Emplacement(int numeroEmplacement) {
		super();
		this.numeroEmplacement = numeroEmplacement;
		this.vacancier = null;
		this.date = null;
	}
	
	public int getNumeroEmplacement() {
		return numeroEmplacement;
	}

	public Vacancier getVacancier() {
		return vacancier;
	}

	public void setVacancier(Vacancier vacancier) {
		this.vacancier = vacancier;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Emplacement [numeroEmplacement=" + numeroEmplacement
				+ ", vacancier=" + vacancier + ", date=" + date + "]";
	}

	
	
}
