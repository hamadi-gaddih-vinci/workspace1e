
public class TestCamping {
	
	
	public static void main(String [] args){
		System.out.println("Le camping compte 5 emplacements");
		Camping camping = new Camping(5);
		Vacancier va = new Vacancier("ida", "noma","1aaa000");
		Vacancier vb = new Vacancier("idb", "nomb","1bbb000");
		Vacancier vc = new Vacancier("idc", "nomc","1ccc000");
		Vacancier vd = new Vacancier("idd", "nomd","1ddd000");
		System.out.println();
		System.out.println("le vacancier a demande l'emplacement 3, il devrait recevoir l'emplacement 3");
		if(camping.attribuerEmplacement(va,3)!=3){
			System.out.println("KO!");
			return;
		}else{
			System.out.println("OK");
		}
		System.out.println("le vacancier b demande l'emplacement 3, il devrait recevoir l'emplacement 4");
		if(camping.attribuerEmplacement(vb,3)!=4){
			System.out.println("KO!");
			return;
		}else{
			System.out.println("OK");
		}
		System.out.println("le vacancier c demande l'emplacement 3, il devrait recevoir l'emplacement 0");
		if(camping.attribuerEmplacement(vc,3)!=0){
			System.out.println("KO!");
			return;
		}else{
			System.out.println("OK");
		}
		
		System.out.println("la voiture 1aaa000 est autorisee");
		if(!camping.estAutorisee("1aaa000")){
			System.out.println("KO!");
			return;
		}else{
			System.out.println("OK");
		}
		
		System.out.println("le vacancier a libere son emplacement, cette action est possible");
		if(!camping.libererEmplacement(va)){
			System.out.println("KO!");
			return;
		}else{
			System.out.println("OK");
		}
		
		System.out.println("le vacancier a libere son emplacement, cette action n'est plus possible");
		if(camping.libererEmplacement(va)){
			System.out.println("KO!");
			return;
		}else{
			System.out.println("OK");
		}
		
		System.out.println("la voiture 1aaa000 n'est plus autorisee");
		if(camping.estAutorisee("1aaa000")){
			System.out.println("KO!");
			return;
		}else{
			System.out.println("OK");
		}
		System.out.println("le vacancier d demande l'emplacement 3, il devrait recevoir l'emplacement 3");
		if(camping.attribuerEmplacement(vd,3)!=3){
			System.out.println("KO!");
			return;
		}else{
			System.out.println("OK");
		}
		System.out.println("Les tests proposes ont reussi");
		System.out.println("Il faut en ajouter!");
		System.out.println("(Camping plein, ...)");
		
	}
}
