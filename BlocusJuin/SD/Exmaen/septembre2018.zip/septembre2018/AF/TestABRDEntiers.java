import java.util.ArrayList;
import java.util.Scanner;


public class TestABRDEntiers {
	
	private final static Scanner scanner = new Scanner(System.in);	
	
	/**
	 * Cette methode verifie qu'un resultat attendu est bien un resultat obtenu.
	 * @param messageErreur message a afficher en cas de probleme
	 * @param attendu la valeur qu'on s'attendait a recevoir
	 * @param recu la valeur qu'on a re�u en realite
	 */
	
	private static void assertEquals(String messageErreur, Object attendu, Object recu) {
		if (attendu==null) {
			if (recu!=null) {
				System.out.println();
				System.out.println(messageErreur+". Attendu="+attendu+" re�u="+recu);
				System.exit(0);
			}
		} else if (!attendu.equals(recu)) {
			System.out.println();
			System.out.println(messageErreur+". Attendu="+attendu+" re�u="+recu);
			System.exit(0);			
		}
	}
	
	public static ABRDEntiers arbreEnonce(){
		
		ABRDEntiers a = new ABRDEntiers();
		a.insere(8);
		a.insere(4);
		a.insere(2);
		a.insere(6);
		a.insere(4);
		a.insere(7);
		a.insere(12);
		a.insere(8);
		a.insere(11);
		a.insere(8);
		return a;
	}
	
	
	public static ABRDEntiers arbreVide(){
		return new ABRDEntiers();
	}
	

	public static void main(String[] args) {
		System.out.println("*****************************************");
		System.out.println("Programme Test pour la classe ABRDEntiers");
		System.out.println("*****************************************");

		int choix = 0;
		do {
			System.out.println();
			System.out.println("1 -> Tester la methode toArrayListOrdreDecroissant()");
			System.out.println("2 -> Tester la methode nombreOccurrences()");
			System.out.println();
			System.out.print("Votre choix : ");
			choix = scanner.nextInt();
			switch (choix) {
			case 1:
				testToArrayListOrdreDecroissant();
				break;
			case 2:
				testNombreOccurrences();
				break;
			default:
				break;
			}

		} while (choix >= 1 && choix <= 2);
		
		
		System.out.println();
			
	}

	

	private static void testToArrayListOrdreDecroissant() {
		System.out.print("test1 : arbre enonce");
		ABRDEntiers a = arbreEnonce();
		ArrayList<Integer> arrayListObtenue = a.toArrayListOrdreDecroissant();
		assertEquals("test1 ko", "[12, 11, 8, 8, 8, 7, 6, 4, 4, 2]", arrayListObtenue.toString());
		System.out.println(" ok");
		
		System.out.print("test2 : arbre vide");
		a = arbreVide();
		arrayListObtenue = a.toArrayListOrdreDecroissant();
		assertEquals("test2 ko", "[]", arrayListObtenue.toString());
		System.out.println(" ok");
		
	}
	
	private static void testNombreOccurrences() {
		System.out.print("test1 : arbre enonce");
		ABRDEntiers a = arbreEnonce();
		assertEquals("test1 ko  nombre occurrences 4", 2, a.nombreOccurrences(4));
		assertEquals("test1 ko  nombre occurrences 0", 0, a.nombreOccurrences(0));
		assertEquals("test1 ko  nombre occurrences 6", 1, a.nombreOccurrences(6));
		assertEquals("test1 ko  nombre occurrences 8", 3, a.nombreOccurrences(8));
		assertEquals("test1 ko  nombre occurrences 9", 0, a.nombreOccurrences(9));
		System.out.println(" ok");
		System.out.print("test2 : arbre vide");
		a = arbreVide();
		assertEquals("test2 ko  nombre occurrences 2", 0, a.nombreOccurrences(2));
		System.out.println(" ok");
	}
}
