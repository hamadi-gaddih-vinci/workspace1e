import java.util.ArrayList;

/**
 * 
 * @author 													-------> METTEZ ICI VOS NOM ET PRENOM
 * 
 * 
 */
public class ABRDEntiers {
	
	private NoeudEntier racine;

	
	public ABRDEntiers () {
		racine = null ;
	}
	
	// A NE PAS MODIFIER! VA SERVIR POUR LES TESTS!!!
	/**
	 * insere un entier dans l'ABR
	 * Les doublons sont acceptes 
	 * @param entier l'entier a inserer
	 */
	public void insere (int entier) {		
		racine = insere(racine, entier);
	}
	
	// A NE PAS MODIFIER! VA SERVIR POUR LES TESTS!!!
	private NoeudEntier insere (NoeudEntier n, int entier) {	
		if (n == null) {
			return new NoeudEntier(entier);
		} else {
			if (entier < n.entier)
				n.gauche = insere(n.gauche, entier);
			else 
				n.droit = insere(n.droit, entier);
		}
		return n;
	}
	
	/**
	 * remplit et revoie une arrayList avec les entiers contenus dans l'arbre
	 * les entiers y seront places par ordre decroissant
	 * @return une arrayList avec les entiers contenus dans l'arbre 
	 */
	public ArrayList<Integer> toArrayListOrdreDecroissant(){
		// TODO
		return null;
		// ajoutez une methode private recursive (cfr enonce)
	}


	
	/**
	 * calcule et renvoie le nombre de fois qu'apparait l'entier passe en parametre
	 * @param entier
	 * @return le nombre d'occurrences de l'entier
	 */
	public int nombreOccurrences(int entier){		
		// TODO
		return 0;
		// ajoutez une methode private recursive EFFICACE (cfr enonce)
		
	}

	

	// classe interne
	public class NoeudEntier {

      private int entier; 
		private NoeudEntier gauche;
		private NoeudEntier droit;

		private NoeudEntier (int entier) {
			this.entier = entier;
			this.gauche = null;
			this.droit = null;
		}
		
		private NoeudEntier (NoeudEntier g, int entier, NoeudEntier d) {
			this.entier = entier;
			this.gauche = g;
			this.droit = d;
		}
	}

}
