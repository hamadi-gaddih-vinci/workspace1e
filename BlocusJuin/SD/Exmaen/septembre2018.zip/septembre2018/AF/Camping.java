
import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
/**
 * 
 * @author 													-------> METTEZ ICI VOS NOM ET PRENOM
 * 
 * 
 */
public class Camping {
	
	// TODO
	// respectez bien les structures de donnees indiquees dans l'enonce
	
		
	/**
	 * construit un camping contenant nombreEmplacements
	 * @param nombreEmplacements le nombre d'emplacements
	 * @throws IllegalArgumentException si le nombre d'emplacements est negatif ou nul
	 */
	public Camping(int nombreEmplacements) {
		// TODO
		
	}
	
	/**
	 * attribue un emplacement au vacancier passe en parametre et enregistre sa date d'arrivee
	 * L'emplacement est celui demande s'il est libre, sinon ce sera le plus proche apres celui-ci
	 * @param vacancier le vacancier qui demande un emplacement
	 * @param numeroEmplacement le numero de l'emplacement prefere
	 * @return le numero de l'emplacement attribue ou -1 s'il n'y en a plus de libre
	 * @throws IllegalArgumentException si le vacancier est null ou si le numero d'emplacement n'existe pas
	 * @throws IllegalStateException si le vacancier possede deja un emplacement
	 */
	public int attribuerEmplacement(Vacancier vacancier, int numeroEmplacement) {
		
		// TODO
		return 0;
		
		// l'emplacement attribue est celui demande en parametre s'il est libre
		// sinon c'est l'emplacement le plus proche de  celui-ci
		// veuillez suivre les indications donnees dans l'enonce!
		
		// pour obtenir la date du jour : LocalDate.now()

	}
	
	
	/**
	 * libere un emplacement
	 * @param vacancier, le vacancier qui libere son emplacement
	 * @return true si l'emplacement a ete libere, false si le vacancier n'est pas repertorie
	 * @throws IllegalArgumentException si le vacancier est null
	 */
	public boolean libererEmplacement(Vacancier vacancier) {
		// TODO
		return false;
	}	
	
	/**
	 * verifie si la voiture dont le numero de plaque est passe en parametre est autorisee
	 * @param plaqueVoiture la plaque de la voiture verifiee
	 * @return true si la plaque est autorisee, false sinon
	 * @throws IllegalArgumentException si la plaque est null
	 */
	public boolean estAutorisee(String plaqueVoiture){
		// TODO
		return false;
	}
}
