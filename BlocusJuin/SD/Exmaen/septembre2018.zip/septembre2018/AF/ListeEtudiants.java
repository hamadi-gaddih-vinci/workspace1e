/**
 * Cette liste gere une liste d'etudiants
 * Elle ne peut etre vide
 * Elle ne contient pas de doublons
 * Le numero d'un etudiant correspond a sa position dans la liste
 * La numerotation commence a 1
 * 
 * @author 													-------> METTEZ ICI VOS NOM ET PRENOM
 * 
 * 
 */
public class ListeEtudiants {

	private NoeudEtudiant tete;
	private int nombreEtudiants;
	private NoeudEtudiant noeudDerGet;
	private int numeroDerGet;
	// N'ajoutez pas d'autres attributs

	/**
	 * construit une liste avec 1 etudiant
	 * @param etudiant le premier etudiant a placer dans la liste
	 * @throws IllegalArgumentException si etudiant est null
	 */
	public ListeEtudiants(Etudiant etudiant){
		if(etudiant==null)
			throw new IllegalArgumentException();
		this.tete = new NoeudEtudiant(etudiant,null);
		this.nombreEtudiants=1;
		this.noeudDerGet = tete;
		this.numeroDerGet = 1;
	}


	public String toString(){
		return "Voici la liste des etudiants :"+toString(tete,1);
	}

	private String toString(NoeudEtudiant noeud, int numero) {
		if(noeud==null)
			return "";
		return "\n" + numero +" : "+ noeud.etudiant  + toString(noeud.suivant,numero+1);
	}

	/**
	 * ajoute un etudiant en fin de liste a condition qu'il n'y soit pas encore
	 * @param etudiant l'etudiant a ajouter
	 * @return true si l'etudiant a ete ajoute, false s'il etait deja present
	 * @throws IllegalArgumentException si etudiant est null
	 */
	public boolean ajoutEnFin(Etudiant etudiant){
		return false;
		//TODO
	}

	/**
	 * renvoie l'etudiant qui a le numero passe en parametre
	 * @param numero le numero demande (la numerotation des etudiants commence a 1)
	 * @return l'etudiant correspondant au numero
	 * @throws IllegalArgumentException si le numero demande n'est pas attribue
	 */
	public Etudiant getEtudiant(int numero){
		return null;
		//TODO
		// Veuillez suivre l'indication suivante :
		// Pour limiter le parcours, le parcours de la liste se fait en partant de la tete ou de noeudDerGet 
	}



	// Classe interne NoeudEtudiant
	private class NoeudEtudiant{

		private Etudiant etudiant;
		private NoeudEtudiant suivant;


		private NoeudEtudiant(Etudiant etudiant) {
			this(etudiant, null);
		}

		private NoeudEtudiant(Etudiant etudiant, NoeudEtudiant suivant) {
			this.etudiant = etudiant;
			this.suivant = suivant;
		}
	}
}
