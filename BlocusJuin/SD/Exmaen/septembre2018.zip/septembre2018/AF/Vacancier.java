
public class Vacancier {

	private String  numeroIdentite;
	private String nom;
	private String plaqueVoiture;
	

	public Vacancier(String numeroIdentite, String nom, String plaqueVoiture) {
		super();
		this.numeroIdentite = numeroIdentite;
		this.nom = nom;
		this.plaqueVoiture = plaqueVoiture;
	}

	public String getNumeroIdentite() {
		return numeroIdentite;
	}

	public String getNom() {
		return nom;
	}

	public String getPlaqueVoiture() {
		return plaqueVoiture;
	}
	

	@Override
	public String toString() {
		return "Vacancier [numeroIdentite=" + numeroIdentite + ", nom=" + nom
				+ ", plaqueVoiture=" + plaqueVoiture + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vacancier other = (Vacancier) obj;
		if (numeroIdentite == null) {
			if (other.numeroIdentite != null)
				return false;
		} else if (!numeroIdentite.equals(other.numeroIdentite))
			return false;
		return true;
	}
	
}
