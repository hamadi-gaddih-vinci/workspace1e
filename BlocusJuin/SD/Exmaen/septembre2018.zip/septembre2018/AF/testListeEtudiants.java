
public class testListeEtudiants {
	
	public static java.util.Scanner scanner = new java.util.Scanner(System.in);

	public static void main(String [] args){
		
		ListeEtudiants l = new ListeEtudiants(new Etudiant("dupont", "pierre"));
		System.out.println(l);
		System.out.println("getEtudiant(1) --> dupont : " + l.getEtudiant(1));	
		System.out.println("ajoutEnFin(durand)");
		System.out.println(l.ajoutEnFin(new Etudiant("durand", "paul")));
		System.out.println(l);
		System.out.println("getEtudiant(2) --> durand : " + l.getEtudiant(2));
		System.out.println("getEtudiant(1) --> dupont : " + l.getEtudiant(1));
		System.out.println("ajoutEnFin(dubois)");
		System.out.println(l.ajoutEnFin(new Etudiant("dubois", "jean")));
		System.out.println(l);
		System.out.println("getEtudiant(3) --> dubois : " + l.getEtudiant(3));
		System.out.println("getEtudiant(3) --> dubois : " + l.getEtudiant(3));
		System.out.println("getEtudiant(1) --> dupont : " + l.getEtudiant(1));
		System.out.println("getEtudiant(2) --> durand : " + l.getEtudiant(2));
		System.out.println("getEtudiant(3) --> dubois : " + l.getEtudiant(3));		
		System.out.println("ajoutEnFin(dubois)");
		System.out.println(l.ajoutEnFin(new Etudiant("dubois", "jean")));
		System.out.println(l);
		
	}

}
