import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;


public class TestDequeUSImpl {
	private final static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {	
		
		System.out.println("*****************************************");
		System.out.println("Programme Test pour la classe DequeUSImpl");
		System.out.println("*****************************************");
	
		int choix = 0;
		do {
			System.out.println();
			System.out.println("1 -> Tester la methode ajouter()");
			System.out.println("2 -> Tester la methode min()");
			System.out.println("3 -> Tester la methode supprimerMin()");
			System.out.println("4 -> Tester la methode iterator()");
			System.out.println();
			System.out.print("Votre choix : ");
			choix = scanner.nextInt();
			System.out.println();
			System.out.println();
			switch (choix) {
			case 1:
				testAjouter();
				break;
			case 2:
				testMin();
				break;
			case 3:				
				testSupprimerMin();
				break;
			case 4:				
				testIterator();
				break;
			default:
				break;
			}

		} while (choix >= 1 && choix <= 4);
	}
	
	

	private static void testIterator() {
		
			System.out.println("Tests methode iterator()");
			System.out.println();
			System.out.print("Test 1 : dequeVide :");
			DequeUSImpl dequeVide = new DequeUSImpl();
			Iterator<Integer> it = dequeVide.iterator();
			try{
				if(it.hasNext()){
					System.out.println(" KO, hasNext() doit renvoyer false");
					return;
				}
			
			}catch (Exception ex){
				System.out.println(" KO, il y a eu Exception lors de l'appel de la methode hasNext()!: ");
				ex.printStackTrace();
				return;
			}
			try{
				it.next();
					System.out.println("KO, il fallait une NoSuchElementException lors d'1 next()");
					return;	
			}catch (NoSuchElementException ex){
				
			}catch (Exception ex){
				System.out.println(" KO, il y a eu Exception lors de l'appel de la methode next() qui n'est pas une NoSuchElementException : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			System.out.print("Test 2 : deque 1 2 3 :");
			int[] t123 = {1,2,3};
			DequeUSImpl deque123 = new DequeUSImpl(t123);
			it = deque123.iterator();
			if(!it.hasNext()){
				System.out.println(" KO, le 1er appel de hasNext() doit renvoyer true");
				return;
			}
			try{
				int next = it.next();
				if(next!=1){
					System.out.println("le 1er next() a renvoye : "+ next);
					return;	
				}	
			}catch (NoSuchElementException ex){
				System.out.println("KO, il a eu une  NoSuchElementException lors du 1er next()");
				return;	
			}catch (Exception ex){
				System.out.println(" KO, il y a eu Exception lors du 1er next ");
				ex.printStackTrace();
				return;
			}
			
			if(!it.hasNext()){
				System.out.println(" KO, le 2�me appel de hasNext() doit renvoyer true");
				return;
			}
			try{
				int next = it.next();
				if(next != 2){
					System.out.println("le 2eme next() a renvoye : "+ next);
					return;	
				}	
			}catch (NoSuchElementException ex){
				System.out.println("KO, il a eu une  NoSuchElementException lors du 2eme next()");
				return;	
			}catch (Exception ex){
				System.out.println(" KO, il y a eu Exception lors du 2eme next ");
				ex.printStackTrace();
				return;
			}
			
			if(!it.hasNext()){
				System.out.println(" KO, le 3eme appel de hasNext() doit renvoyer true");
				return;
			}
			try{
				int next = it.next();
				if(next!=3){
					System.out.println("le 3eme next() a renvoye : "+ next);
					return;	
				}	
			}catch (NoSuchElementException ex){
				System.out.println("KO, il a eu une  NoSuchElementException lors du 3eme next()");
				return;	
			}catch (Exception ex){
				System.out.println(" KO, il y a eu Exception lors du 3eme next ");
				ex.printStackTrace();
				return;
			}
			
			try{
				if(it.hasNext()){
					System.out.println(" KO, hasNext() doit renvoyer apres 3 next()");
					return;
				}
			
			}catch (Exception ex){
				System.out.println(" KO, il y a eu Exception lors de l'appel de la methode hasNext() apres 3 next() ");
				ex.printStackTrace();
				return;
			}
			try{
				it.next();
					System.out.println("KO, il fallait une NoSuchElementException lors du 4eme next()");
					return;	
			}catch (NoSuchElementException ex){
				
			}catch (Exception ex){
				System.out.println(" KO, il y a eu Exception lors du 4eme appel de la methode next() qui n'est pas une NoSuchElementException : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			System.out.println("Tous les tests ont reussi!");	
			
		
	}



	private static void testAjouter() {
		System.out.println("Tests methode ajouter()");
		System.out.println();
		System.out.print("Test 1 : dequeVide : ajout 9");
		DequeUSImpl dequeVide = new DequeUSImpl();
		try{
			dequeVide.ajouter(9);
			if(dequeVide.taille()!=1){
				System.out.println(" KO : l'attribut taille vaut : "+ dequeVide.taille());
				return;
			}
			if(!dequeVide.toString().equals("9")){
				System.out.println(" KO : votre liste contient : "+ dequeVide);
				return;
			}
		
		}catch (Exception ex){
			System.out.println(" KO, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		
		System.out.print("Test 2 : deque 1 3 5 : ajout 0");
		int[] t135 = {1,3,5};
		DequeUSImpl deque135 = new DequeUSImpl(t135);
		try{
			boolean ajoutOK = deque135.ajouter(0);
			if(!ajoutOK){
				System.out.println(" KO : la methode a renvoye false");
				return;
			}
			if(deque135.taille()!=4){
				System.out.println(" KO : l'attribut taille vaut : "+ deque135.taille());
				return;
			}
			if(!deque135.toString().equals("0 1 3 5")){
				System.out.println(" KO : votre liste contient : "+ deque135);
				return;
			}
		}
		catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		System.out.print("Test 3 : deque 1 3 5 : ajout 9");		
		deque135 = new DequeUSImpl(t135);
		try{
			boolean ajoutOK = deque135.ajouter(9);
			if(!ajoutOK){
				System.out.println(" KO : la methode a renvoye false");
				return;
			}
			if(deque135.taille()!=4){
				System.out.println(" KO : l'attribut taille vaut : "+ deque135.taille());
				return;
			}
			if(!deque135.toString().equals("1 3 5 9")){
				System.out.println(" KO : votre liste contient : "+ deque135);
				return;
			}
		}
		catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		System.out.print("Test 4 : deque 1 3 5 : ajout 1");
		deque135 = new DequeUSImpl(t135);
		try{
			boolean ajoutOK = deque135.ajouter(1);
			if(!ajoutOK){
				System.out.println(" KO : la methode a renvoye false");
				return;
			}
			if(deque135.taille()!=4){
				System.out.println(" KO : l'attribut taille vaut : "+ deque135.taille());
				return;
			}
			if(!deque135.toString().equals("1 1 3 5")){
				System.out.println(" KO : votre liste contient : "+ deque135);
				return;
			}
		}
		catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		System.out.print("Test 5 : deque 1 3 5 : ajout 5");
		deque135 = new DequeUSImpl(t135);
		try{
			boolean ajoutOK = deque135.ajouter(5);
			if(!ajoutOK){
				System.out.println(" KO : la methode a renvoye false");
				return;
			}
			if(deque135.taille()!=4){
				System.out.println(" KO : l'attribut taille vaut : "+ deque135.taille());
				return;
			}
			if(!deque135.toString().equals("1 3 5 5")){
				System.out.println(" KO : votre liste contient : "+ deque135);
				return;
			}
		}
		catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		System.out.print("Test 6 : deque 1  : ajout 1");
		int[] t1 = {1};
		DequeUSImpl deque1 = new DequeUSImpl(t1);
		try{
			boolean ajoutOK = deque1.ajouter(1);
			if(!ajoutOK){
				System.out.println(" KO : la methode a renvoye false");
				return;
			}
			if(deque1.taille()!=2){
				System.out.println(" KO : l'attribut taille vaut : "+ deque1.taille());
				return;
			}
			if(!deque1.toString().equals("1 1")){
				System.out.println(" KO : votre liste contient : "+ deque1);
				return;
			}
		}
		catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		System.out.print("Test 7 : deque 1 3 5 : ajout 2");
		deque135 = new DequeUSImpl(t135);
		try{
			boolean ajoutOK = deque135.ajouter(2);
			if(ajoutOK){
				System.out.println(" KO : la methode a renvoye true");
				return;
			}
			if(deque135.taille()!=3){
				System.out.println(" KO : l'attribut taille vaut : "+ deque135.taille());
				return;
			}
			if(!deque135.toString().equals("1 3 5")){
				System.out.println(" KO : votre liste contient : "+ deque135);
				return;
			}
		}
		catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		System.out.print("Test 8 : agrandissement de table a partir du deque 1 3 5 : ajout 7 8 9 ");
		deque135 = new DequeUSImpl(t135);
		try{
			boolean ajoutOK = deque135.ajouter(7);
			if(!ajoutOK){
				System.out.println(" KO : la methode a renvoye false");
				return;
			}
			ajoutOK = deque135.ajouter(8);
			if(!ajoutOK){
				System.out.println(" KO : la methode a renvoye false");
				return;
			}
			ajoutOK = deque135.ajouter(9);
			if(!ajoutOK){
				System.out.println(" KO : la methode a renvoye false");
				return;
			}
			if(deque135.taille()!=6){
				System.out.println(" KO : l'attribut taille vaut : "+ deque135.taille());
				return;
			}
			if(!deque135.toString().equals("1 3 5 7 8 9")){
				System.out.println(" KO : votre liste contient : "+ deque135);
				return;
			}
		}
		catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		System.out.println("Tous les tests ont reussi!");	
		
		
		
	}

	private static void testMin() {
		System.out.println("Tests methode min()");
		System.out.println();
		System.out.print("Test 1 : dequeVide :");
		DequeUSImpl dequeVide = new DequeUSImpl();
		try{
			dequeVide.min();
			System.out.println(" KO, il fallait une DequeVideException");
			return;
		}catch (DequeVideException e){
			
		}catch (Exception ex){
			System.out.println(" KO, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		
		System.out.print("Test 2 : deque 1 2 3 :");
		int[] t123 = {1,2,3};
		DequeUSImpl deque123 = new DequeUSImpl(t123);
		try{
			int min = deque123.min();
			if(min!=1){
				System.out.println(" KO : min renvoye : "+ min);
				return;
			}
			if(!deque123.toString().equals("1 2 3")){
				System.out.println(" KO : contenu liste a change : "+ deque123);
				return;
			}
		}catch (DequeVideException e){
			System.out.println(" ko, il y a eu DequeVideException : ");
			return;
		}catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		System.out.println("Tous les tests ont reussi!");	
		
	}

	private static void testSupprimerMin() {
		
		System.out.println("Tests methode supprimerMin()");
		System.out.println();
		System.out.print("Test 1 : dequeVide :");
		DequeUSImpl dequeVide = new DequeUSImpl();
		try{
			dequeVide.supprimerMin();
			System.out.println(" KO, il fallait une DequeVideException");
			return;
		}catch (DequeVideException e){

		}catch (Exception ex){
			System.out.println(" KO, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
		
		
		System.out.print("Test 2 : deque 1 2 3 :");
		int[] t123 = {1,2,3};
		DequeUSImpl deque123 = new DequeUSImpl(t123);
		try{
			int s = deque123.supprimerMin();
			if(s!=1){
				System.out.println(" KO : min renvoye : "+ s);
				return;
			}
			if(deque123.taille()!=2){
				System.out.println(" KO : l'attribut taille vaut : "+ deque123.taille());
				return;
			}
			if(!deque123.toString().equals("2 3")){
				System.out.println(" KO : votre liste contient : "+ deque123);
				return;
			}
		}catch (DequeVideException e){
			System.out.println(" ko, il y a eu DequeVideException : ");
			return;
		}catch (Exception ex){
			System.out.println(" ko, il y a eu Exception : ");
			ex.printStackTrace();
			return;
		}
		System.out.println(" ok");
	
		
		System.out.println("Tous les tests ont reussi!");
	}

}
