
public class TestUS {

	public static void main(String[] args) {
		System.out.println("***********************************");
		System.out.println("Tests de la methode placerElement()");
		System.out.println("***********************************");
		US u = new US();
		System.out.println("placerElement(3)");
		u.placerElement(3);
		System.out.println(u);
		System.out.println();
		System.out.println("placerElement(5)");
		u.placerElement(5);
		System.out.println(u);
		System.out.println();
		System.out.println("placerElement(2)");
		u.placerElement(2);
		System.out.println(u);
		System.out.println();
		System.out.println("placerElement(4)");
		u.placerElement(4);
		System.out.println(u);
		System.out.println();
		System.out.println("placerElement(8)");
		u.placerElement(8);
		System.out.println(u);
		System.out.println();
		System.out.println("placerElement(7)");
		u.placerElement(7);
		System.out.println(u);
		System.out.println();
		System.out.println("placerElement(6)");
		u.placerElement(6);
		System.out.println(u);
		System.out.println();
		
	}
}
