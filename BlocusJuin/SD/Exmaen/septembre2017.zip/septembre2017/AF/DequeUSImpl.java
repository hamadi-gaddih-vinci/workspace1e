import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;


//METTEZ VOTRE NOM ET VOTRE PRENOM!!!!

public class DequeUSImpl implements DequeUS{

	private int[] t;
	private int taille;		//taille logique
	private int indiceMin;	
	private int indiceMax;
	private int numVersion;   // pour l'iterateur
	
	// N'ajoutez pas d'autres attributs

	public DequeUSImpl(){
		t = new int[4];
		indiceMin = 0;
		indiceMax = 0;
		taille = 0;
		numVersion = 1;
	}
	
	// Va servir pour les tests 
	// A ne pas modifier!!!
	public DequeUSImpl(int[] tableARecopier){
		if(tableARecopier==null||tableARecopier.length==0)
			throw new IllegalArgumentException();
		t = new int[tableARecopier.length+4];
		for (int i = 0; i < tableARecopier.length; i++) {
			t[i+2]=tableARecopier[i];
		}
		indiceMin = 2;
		indiceMax = 2 + tableARecopier.length - 1;
		taille = tableARecopier.length;
	}
	
	// Va servir pour les tests 
	// A ne pas modifier!!!
	public String toString(){
		String aRenvoyer = "";
		if(estVide())
			return aRenvoyer;
		aRenvoyer+=t[indiceMin];
		for (int i = indiceMin+1; i <= indiceMax; i++) {
			aRenvoyer += " "+t[i];
		}
		return aRenvoyer;
	}
	
	@Override
	public boolean estVide() {
		return taille==0;
	}

	@Override
	public int taille() {
		return taille;
	}

	private void agrandirTable() {
		//TODO

	}

	@Override
	public boolean ajouter(int entier) {
		// TODO Auto-generated method stub
		numVersion++;
		return false;
	}

	@Override
	public int min() throws DequeVideException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int supprimerMin() throws DequeVideException {
		// TODO Auto-generated method stub
		numVersion++;
		return 0;
	}
	
	@Override
	public Iterator iterator() {
		return new IterateurImpl();
	}
	
	private class IterateurImpl implements Iterator{

		private int indiceCourant;
		private int version;

		private IterateurImpl() {
			//TODO
			version = numVersion;
		}

		@Override
		public boolean hasNext() {
			// TODO
			return false;
		}

		@Override
		public Integer next() {
			// TODO
			if(version!=numVersion)
				throw new ConcurrentModificationException();
			return 0;
		}
		
		@Override
		// A NE PAS COMPLETER : Les suppressions sont interdites
		public void remove() {
			throw new UnsupportedOperationException();			
		}

	}

}
