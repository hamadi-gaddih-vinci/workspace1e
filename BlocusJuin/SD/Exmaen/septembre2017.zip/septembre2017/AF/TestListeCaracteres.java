import java.util.Scanner;

public class TestListeCaracteres {

	private static Scanner scanner = new Scanner(System.in);

	/**
	 * Cette methode verifie qu'un resultat attendu est bien un resultat obtenu.
	 * 
	 * @param messageErreur message a afficher en cas de probleme
	 * @param attendu la valeur qu'on s'attendait a recevoir
	 * @param recu la valeur qu'on a re�u en realite
	 */
	private static void assertEquals(String messageErreur, Object attendu, Object recu) {
		if (attendu==null) {
			if (recu!=null) {
				System.out.println();
				System.out.println("     "+messageErreur+" attendu="+attendu+" re�u="+recu);
				System.exit(0);
			}
		} else if (!attendu.equals(recu)) {
			System.out.println();
			System.out.println("    "+messageErreur+" attendu="+attendu+" re�u="+recu);
			System.exit(0);			
		}
	}

	public static void main(String[] args) {

		System.out.println("*********************************************");
		System.out.println("Programme Test pour la classe ListeCaracteres");
		System.out.println("*********************************************");
		int choix = 0;
		do {
			System.out.println("1 -> Tester la methode supprimer");
			System.out.println("2 -> Tester la methode nombreCaracteresDifferents");
			System.out.println("3 -> Tester la methode nombreChiffres");
			System.out.println("4 -> Tester la methode remplacer");
			System.out.println();
			System.out.print("Entrez votre choix : ");
			choix = scanner.nextInt();
			switch (choix) {
			case 1:
				testSupprimer();
				break;
			case 2:
				testNombreCaracteresDifferents();
				break;
			case 3:
				testNombreChiffres();
				break;
			case 4:
				testRemplacer();
				break;
			default:
				break;
			}
		} while (choix >= 1 && choix <= 4 );
	}



	private static void testSupprimer() {
		char [] caracteres = {'a','b','c','d'};	
		ListeCaracteres l = new ListeCaracteres(caracteres);
		System.out.print("Test 1 : liste testee : "+l +"     appel methode : supprimer(1)");
		try {
			char c = l.supprimer(1);
			assertEquals("ko : caractere renvoye : ",'b',c);
			assertEquals("ko : liste apres suppression : "," a c d",l.toString());
			System.out.println(" : ok");
		} catch (Exception e) {
			System.out.println("ko : il y a eu exception : ");
			e.printStackTrace();
			return;
		}
	
		l = new ListeCaracteres(caracteres);
		System.out.print("Test 2 : liste testee : "+l +"     appel methode : supprimer(2)");
		try {
			char c = l.supprimer(2);
			assertEquals("ko : caractere renvoye : ",'c',c);
			assertEquals("ko : liste apres suppression : "," a b d",l.toString());
			System.out.println(" : ok");
		} catch (Exception e) {
			System.out.println("ko : il y a eu exception : ");
			e.printStackTrace();
			return;
		}
	
		
		l = new ListeCaracteres(caracteres);
		System.out.print("Test 3 : liste testee : "+l +"     appel methode : supprimer(3)");
		try {
			char c = l.supprimer(3);
			assertEquals("ko : caractere renvoye : ",'d',c);
			assertEquals("ko : liste apres suppression : "," a b c",l.toString());
			System.out.println(" : ok");
		} catch (Exception e) {
			System.out.println("ko : il y a eu exception : ");
			e.printStackTrace();
			return;
		}
		
		l = new ListeCaracteres(caracteres);
		System.out.print("Test 4 : liste testee : "+l +"     appel methode : supprimer(0)");	
		try {
			char c = l.supprimer(0);
			assertEquals("ko : caractere renvoye : ",'a',c);
			assertEquals("ko : liste apres suppression : "," b c d",l.toString());
			System.out.println(" : ok");
		} catch (Exception e) {
			System.out.println("ko : il y a eu exception : ");
			e.printStackTrace();
			return;
		}

		l = new ListeCaracteres(caracteres);
		System.out.print("Test 5 : liste testee : "+l +"     appel methode : supprimer(-1)");
		try {
			l.supprimer(-1);
			System.out.println("ko : il n'y a pas eu IllegalArgumentException : ");
			return;
		} 
		catch (IllegalArgumentException e) {
			assertEquals("ko : liste apres suppression : "," a b c d",l.toString());
			System.out.println(" : ok");	
		}
		catch (Exception e) {
			System.out.println("ko : il y a eu exception : ");
			e.printStackTrace();
			return;
		}
		l = new ListeCaracteres(caracteres);
		System.out.print("Test 6 : liste testee : "+l +"     appel methode : supprimer(4)");
		try {
			l.supprimer(4);
			System.out.println("ko : il n'y a pas eu IllegalArgumentException : ");
			return;
		} 
		catch (IllegalArgumentException e) {
			assertEquals("ko : liste apres suppression : "," a b c d",l.toString());
			System.out.println(" : ok");	
		}
		catch (Exception e) {
			System.out.println("ko : il y a eu exception : ");
			e.printStackTrace();
			return;
		}


		l = new ListeCaracteres();
		System.out.print("Test 7 : liste vide :                appel methode : supprimer(0)");	
		try {
			l.supprimer(0);
			System.out.println("ko : il n'y a pas eu IllegalArgumentException : ");
			return;
		} 
		catch (IllegalArgumentException e) {
			assertEquals("ko : liste apres suppression : ","",l.toString());
			System.out.println(" : ok");	
		}
		catch (Exception e) {
			System.out.println("ko : il y a eu exception : ");
			e.printStackTrace();
			return;
		}
		


		System.out.println("Tous les tests ont reussi!");
		System.out.println();
		System.out.println();
		
	}
	

	private static void testNombreCaracteresDifferents() {
		char [] caracteres1 = {'a','b','c','d'};	
		ListeCaracteres l = new ListeCaracteres(caracteres1);
		System.out.print("Test 1 : liste testee : "+l +"     appel methode : nombreCaracteresDifferents");	
		assertEquals("ko : entier renvoye",4,l.nombreCaracteresDifferents());
		assertEquals("ko : liste apres test : "," a b c d",l.toString());
		System.out.println(" : ok");
		char [] caracteres2 = {'a','b','a','d'};	
		l = new ListeCaracteres(caracteres2);
		System.out.print("Test 2 : liste testee : "+l +"     appel methode : nombreCaracteresDifferents");	
		assertEquals("ko : entier renvoye",3,l.nombreCaracteresDifferents());
		System.out.println(" : ok");
		char [] caracteres3 = {'a','a','a','a'};	
		l = new ListeCaracteres(caracteres3);
		System.out.print("Test 3 : liste testee : "+l +"     appel methode : nombreCaracteresDifferents");	
		assertEquals("ko : entier renvoye",1,l.nombreCaracteresDifferents());
		System.out.println(" : ok");
		l = new ListeCaracteres();
		System.out.print("Test 4 : liste vide :                appel methode : nombreCaracteresDifferents");	
		assertEquals("ko : entier renvoye",0,l.nombreCaracteresDifferents());
		System.out.println(" : ok");
		System.out.println("Tous les tests ont reussi!");
		System.out.println();
		System.out.println();		
	}

	private static void testNombreChiffres(){
		
		char[] caracteres = {'a','b','9','d'};
		ListeCaracteres l;
		l = new ListeCaracteres(caracteres);
		System.out.print("Test 1 : liste testee : "+l+"    appel methode : nombreChiffres : ");
		assertEquals("nombre renvoye ko",1,l.nombreChiffres());
		assertEquals("Attention, liste modifiee! "," a b 9 d",l.toString());
		System.out.println("ok");
		
		char [] caracteres1 = {'9','0','9','0'};
		ListeCaracteres l1;
		l1 = new ListeCaracteres(caracteres1);
		System.out.print("Test 2 : liste testee : "+l1+"    appel methode : nombreChiffres : ");
		assertEquals("nombre renvoye ko",4,l1.nombreChiffres());
		System.out.println("ok");
		
	
		char [] caracteres2 = {'a','b','c','d'};
		ListeCaracteres l2;
		l2 = new ListeCaracteres(caracteres2);
		System.out.print("Test 3 : liste testee : "+l2+"    appel methode : nombreChiffres : ");
		assertEquals("nombre renvoye ko",0,l2.nombreChiffres());
		System.out.println("ok");
	
		ListeCaracteres lV;
		lV = new ListeCaracteres();
		System.out.print("Test 4 : liste vide :               appel methode : nombreChiffres : ");
		assertEquals("nombre renvoye ko",0,lV.nombreChiffres());
		System.out.println("ok");

		
		System.out.println("Tous les tests ont reussi!");
		System.out.println();
		System.out.println();

	}
	private static void testRemplacer() {
		
		char[] caracteres = {'a','b','c','d'};
		ListeCaracteres l;
		l = new ListeCaracteres(caracteres);
		System.out.print("Test 1 : liste testee : "+l+"    appel methode : remplacer('c','x') : ");
		l.remplacer('c', 'x');
		assertEquals("Attention, contenu liste ko ! "," a b x d",l.toString());
		System.out.println("ok");
		
		char[] caracteres1 = {'c','c','c','c'};
		ListeCaracteres l1;
		l1 = new ListeCaracteres(caracteres1);
		System.out.print("Test 2 : liste testee : "+l1+"    appel methode : remplacer('c','x') : ");
		l1.remplacer('c', 'x');
		assertEquals("Attention, contenu liste ko ! "," x x x x",l1.toString());
		System.out.println("ok");
		
		
		l = new ListeCaracteres(caracteres);
		System.out.print("Test 3 : liste testee : "+l+"    appel methode : remplacer('f','x') : ");
		l.remplacer('f', 'x');
		assertEquals("Attention, contenu liste ko ! "," a b c d",l.toString());
		System.out.println("ok");
		
		
		l = new ListeCaracteres();
		System.out.print("Test 3 : liste vide :               appel methode : remplacer('c','x') : ");
		l.remplacer('c', 'x');
		assertEquals("Attention, contenu liste ko ! ","",l.toString());
		System.out.println("ok");
		
		System.out.println("Tous les tests ont reussi!");
		System.out.println();
		System.out.println();
	}

	

	

}
