import java.util.HashSet;

//METTEZ VOTRE NOM ET VOTRE PRENOM!!!!

public class ListeCaracteres {

	private NoeudCaractere tete;
	// N'ajoutez pas d'autres attributs
	
	
	public ListeCaracteres() {
		this.tete=null;
		// N'ajoutez pas de noeud sentinelle!
	}
	
	// A NE PAS MODIFIER --> POUR LES TESTS!!!
	public ListeCaracteres(char[] tableCaracteres) {
		for (int i = tableCaracteres.length-1; i>=0; i--) {
			this.tete=new NoeudCaractere(tableCaracteres[i],tete);
		}	
	}
	
	// A NE PAS MODIFIER --> POUR LES TESTS!!!
	public String toString(){	
		return toString(tete);
	}
	// A NE PAS MODIFIER --> POUR LES TESTS!!!	
	private String toString(NoeudCaractere noeud) {
		if(noeud == null)
			return "";
		return " " + noeud.caractere + toString(noeud.suivant);
	}
	
	/**
	 * verifie la presence du caractere passe en parametre dans la liste
	 * @param caractereRecherche
	 * @return true si le caractere est present dans la liste, false sinon
	 */
	public boolean contient(char caractereRecherche){
		return contient(tete,caractereRecherche);
	}
	
	private boolean contient(NoeudCaractere noeud, char caractereRecherche) {
		if(noeud == null)
			return false;
		if(noeud.caractere==caractereRecherche)
			return true;
		return contient(noeud.suivant, caractereRecherche);
	}
	
	/**
	 * supprime de la liste le noeud qui se trouve a la position passee en parametre
	 * @param position la position du noeud a supprimer
	 * @return le caractere supprime
	 * @throws IllegalArgumentException si la position passee en parametre est invalide
	 */
	public char supprimer(int position){
		//TODO
		return 0;	
	}
	
	/**
	 * calcule le nombre de caracteres differents presents dans la liste
	 * @return le nombre de caracteres differents
	 */
	public int nombreCaracteresDifferents(){
		//TODO
		return 0;
	}
	
	/**
	 * calcule le nombre de chiffres ('0','1','2','3','4','5','6','7','8','9') presents dans la liste
	 * @return le nombre de chiffres 
	 */
	public int nombreChiffres(){
		// TODO
		return 0;
	}
	
	/**
	 * remplace toutes les occurrences du caractere recherche par un nouveau caractere
	 * @param caractereRecherche le caractere a remplacer
	 * @param nouveauCaractere le caractere remplacant
	 */
	
	public void remplacer(char caractereRecherche, char nouveauCaractere){
		// TODO
	}
	

	private class NoeudCaractere{
		private char caractere;
		private NoeudCaractere suivant;

		public NoeudCaractere(char caractere, NoeudCaractere suivant){
			this.caractere = caractere;
			this.suivant = suivant;
		}

	}
}
