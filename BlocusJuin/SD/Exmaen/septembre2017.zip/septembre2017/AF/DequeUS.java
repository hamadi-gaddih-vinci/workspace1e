import java.util.Iterator;

/**
 * Un dequeUs est un deque contenant des entiers qui y apparaissent tries selon l'ordre croissant
 *
 */
public interface DequeUS {
	
	/**
	 * verifie si le deque est vide
	 * @return true si le deque est vide, false sinon
	 */
	public boolean estVide();

	
	/**
	 * renvoie le nombre d'entiers qui se trouvent dans le deque
	 * @return nombre d'entiers
	 */
	public int taille();
	
	
	/**
	 * ajoute un entier en tete ou en queue du deque. Cet ajout ne se fait que si le tri peut etre respecte
	 * @param entier l'entier a ajouter
	 * @return true si l'entier a pu etre ajoute tout en respectant le tri, false sinon
	 */	
	public boolean ajouter(int entier);


	
	/**
	 * renvoie l'entier de tete du deque sans l'enlever
	 * @return le plus petit entier 
	 * @throws DequeVideException si le deque est vide
	 */	
	public int min() throws DequeVideException;


	
	/**
	 * renvoie l'entier de tete du deque et l'enleve
	 * @return le plus petit entier
	 * @throws DequeVideException si le deque est vide
	 */	
	public int supprimerMin() throws DequeVideException;
	
	
	/**
	 * l'iterateur va permettre de parcourir de tous les entiers du deque en commen�ant par le premier
	 * @return un objet de la classe Iterator
	 */
	public Iterator iterator();

}
