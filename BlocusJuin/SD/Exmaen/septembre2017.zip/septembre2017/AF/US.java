
//METTEZ VOTRE NOM ET VOTRE PRENOM!!!!

public class US {
	// TODO

	public US() {
		//TODO
	}

	public void placerElement(int element) {
		//TODO
	}
	

	public String toString(){
		//TODO
		return null;
	}
}
