
public class DessinTriangle {

	public static Tortue tortue = new Tortue();

	public static void main(String args[]) {

		tortue.avancer(100);
		tortue.tournerADroite(120);
		tortue.avancer(100);
		tortue.tournerADroite(120);
		tortue.avancer(100);
		tortue.tournerADroite(120);
		
	}

}

