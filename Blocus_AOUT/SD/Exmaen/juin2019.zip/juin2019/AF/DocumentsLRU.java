import java.util.HashMap;


public class DocumentsLRU {

	private Noeud tete, queue;
	private HashMap<String, Noeud> map;
	
	/**
	 * initialise une liste de taille noeuds avec les documents doc1, doc2, ...
	 * @param taille
	 * @throws IllegalArgumentException la liste est de 3 documents minimum
	 */
	public DocumentsLRU(int taille){
		if(taille<3){
			throw new IllegalArgumentException();
		}
		String doc1 = new String("doc1");
		tete = new Noeud(null,doc1,null);
		map = new HashMap<String, DocumentsLRU.Noeud>();
		Noeud temp = tete;
		map.put(doc1, tete);
		for(int i=2;i<=taille;i++){
			String docI = new String("doc"+i);
			temp.suivant = new Noeud(temp,docI,null);
			temp = temp.suivant;
			map.put(docI, temp);
		}
		queue = temp;
	}
	
	/**
	 * renvoie le noeud contenant le document passe en parametre ou null si le document n'est pas present dans la liste
	 * @param document le document recherche
	 * @return le noeud contenant le document ou null
	 */
	private Noeud donnerNoeud(String document){
		//TODO
		return null;
	}
	
	/**
	 * supprime le noeud passe en parametre
	 * @param noeud le noeud a supprimer
	 */
	private void supprimer(Noeud noeud){
		//TODO
		
	}
	
	/**
	 * ajoute un noeud en tete de liste avec le document passe en parametre
	 * @param document le document a ajouter
	 */
	private void ajouterEnTete(String document){
		//TODO
		
	}
	
	/**
	 * supprime le noeud (et donc le document!) qui se trouve en fin de liste
	 */
	private void supprimerQueue(){
		//TODO
	
	}

	/**
	 * place le document passe en parametre dans la liste selon le mecanisme LRU
	 * @param le document qui est ouvert
	 */
	public void ouvrirDocument(String document){
		//TODO
	
	}
	
	
	public String toString(){
		//TODO
		return null;
	
	}
	
	
	private class Noeud{
		private String document;
		private Noeud precedent;
		private Noeud suivant;
		
		public Noeud(Noeud precedent,String document,Noeud suivant) {
			super();
			this.precedent = precedent;
			this.document = document;	
			this.suivant = suivant;
		}
		
		
	}
}
