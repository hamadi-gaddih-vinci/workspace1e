import java.util.Scanner;
/**
 * @author 
 * 
 */
public class Course {

	private static Scanner scanner = new Scanner(System.in);
	private static Liste liste = null; 

	public static void main(String[] args) {	
		
		System.out.println("********************************************");
		System.out.println("Programme de gestion d'une course automobile");
		System.out.println("********************************************");
		String[] coureurs = {"coureur1", "coureur2", "coureur3"};
		liste = new ListeImpl(coureurs);	
	
		
			System.out.println();
			System.out.println("1 -> Afficher toute la course");
			System.out.println("2 -> Supprimer un coureur");
			System.out.println("3 -> Avancer un coureur");
			System.out.println();
			
			
			// A COMPLETER

	}

}
