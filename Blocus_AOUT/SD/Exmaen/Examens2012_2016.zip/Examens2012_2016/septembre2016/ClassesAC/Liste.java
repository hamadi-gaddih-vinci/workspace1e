public interface Liste {
	
	public int taille();
	
	public boolean estVide();
	
	public String toString();
	
	public boolean supprimer(Object element);
	
	public boolean permuterAvant(Object element);
	
}
