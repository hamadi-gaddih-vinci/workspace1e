
public class TestListeImpl {
	public static void main(String[] args) {	

		System.out.println("****************************************");
		System.out.println("Programme Test pour la classe ListeImpl");
		System.out.println("****************************************");
		
		testPermuterAvant();
		
		testSupprimer();
		
	}
	
	
		
		private static void testSupprimer() {
			System.out.println();
			System.out.println("Tests methode supprimer()");
			
			// Liste vide
			System.out.print("Test 1 : listeVide :");
			ListeImpl listeVide = new ListeImpl();
			try {
				if (listeVide.supprimer("a")){
					System.out.println(" KO : booleen renvoye : true!");
					return;
				}		
			} catch (Exception ex){
				System.out.println(" KO, il y a eu Exception : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			// Pas present
			System.out.print("Test 2 : liste a b c : supprimer d : ");
			String[] tabc = {"a", "b", "c"};
			ListeImpl labc = new ListeImpl(tabc);
			try {
				if (labc.supprimer(new String("d"))){
					System.out.println(" KO : booleen renvoye : true!");
					return;
				}
			} catch (Exception ex){
				System.out.println(" ko, il y a eu Exception : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			// suppression OK
			System.out.print("Test 3 : liste a b c : supprimer b : ");
			labc = new ListeImpl(tabc);
			String[] tac = {"a", "c"};
			ListeImpl lac = new ListeImpl(tac);
			try {
				if (!labc.supprimer(new String("b"))){
					System.out.println(" KO : booleen renvoye : false!");
					return;
				}
				if (labc.taille() != 2){
					System.out.println(" KO : taille obtenue : " + labc.taille());
					return;
				}
				
				if(!labc.equals(lac)){
					System.out.println(" KO : contenu ou double chainage a revoir");
					return;
				}
				
			} catch (Exception ex){
				System.out.println(" ko, il y a eu Exception : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			
			// 2 suppressions
			System.out.print("Test 4 : liste a b c : supprimer 2 x b : ");
			labc = new ListeImpl(tabc);
			try {
				if (!labc.supprimer(new String("b"))){
					System.out.println(" KO : booleen renvoye 1ere supp : false!");
					return;
				}
				if (labc.supprimer(new String("b"))){
					System.out.println(" KO : booleen renvoye 2eme supp : true!");
					return;
				}

			} catch (Exception ex){
				System.out.println(" ko, il y a eu Exception : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			
			// Tout est OK
			System.out.println("Tous les tests de la methode supprimer() ont reussi!");	
		
	}



		// PERMUTER
		private static void testPermuterAvant() {
			System.out.println();
			System.out.println("Tests methode permuterAvant()");
			
			// Liste vide
			System.out.print("Test 1 : listeVide :");
			ListeImpl listeVide = new ListeImpl();
			try {
				if (listeVide.permuterAvant("a")){
					System.out.println(" KO : booleen renvoye : true!");
					return;
				}		
			} catch (Exception ex){
				System.out.println(" KO, il y a eu Exception : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			// Pas de precedent
			System.out.print("Test 2 : liste a b c : permuter a et son precedent (/) : ");
			String[] tabc = {"a", "b", "c"};
			ListeImpl labc = new ListeImpl(tabc);
			try {
				if (labc.permuterAvant(new String("a"))){
					System.out.println(" KO : booleen renvoye : true!");
					return;
				}
			} catch (Exception ex){
				System.out.println(" ko, il y a eu Exception : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			// Permutation OK
			System.out.print("Test 3 : liste a b c : permuter b et son precedent : ");
			labc = new ListeImpl(tabc);
			String[] tbac = {"b", "a", "c"};
			ListeImpl lbac = new ListeImpl(tbac);
			try {
				if (!labc.permuterAvant(new String("b"))){
					System.out.println(" KO : booleen renvoye : false!");
					return;
				}
				if (labc.taille() != 3){
					System.out.println(" KO : taille obtenue : " + labc.taille());
					return;
				}
				
				if(!labc.equals(lbac)){
					System.out.println(" KO : contenu ou double chainage a revoir");
					return;
				}
				
			} catch (Exception ex){
				System.out.println(" ko, il y a eu Exception : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			
			
			// 2 Permutations 
			System.out.print("Test 4 : liste a b c : permuter c et son precedent 2X de suite : ");
			labc = new ListeImpl(tabc);
			String[] tcab = {"c", "a", "b"};
			ListeImpl lcab = new ListeImpl(tcab);
			try {
				labc.permuterAvant(new String("c"));
				labc.permuterAvant(new String("c"));
				if(!labc.equals(lcab)){
					System.out.println(" KO : contenu ou double chainage a revoir");
					return;
				}
				
			} catch (Exception ex){
				System.out.println(" ko, il y a eu Exception : ");
				ex.printStackTrace();
				return;
			}
			System.out.println(" ok");
			// Tout est OK
			System.out.println("Tous les tests de la methode permuterAvant() ont reussi!");	
		}
		
		
}
