
public class TestCadastre {

	public static java.util.Scanner scanner = new java.util.Scanner(System.in);

	public static void main(String[] args) {

		System.out.println("***********************");
		System.out.println("Programme Test Cadastre");
		System.out.println("***********************");
		Cadastre cada = new Cadastre();
		System.out.println("Exemple de l'enonce :");
		Parcelle p1 = new Parcelle("p1");
		Parcelle p2 = new Parcelle("p2");
		Parcelle p3 = new Parcelle("p3");
		Parcelle p4 = new Parcelle("p4");
		Proprietaire propA = new Proprietaire("propA", "");
		Proprietaire propB = new Proprietaire("propB", "");
		Proprietaire propC = new Proprietaire("propC", "");
		cada.ajouteParcelle(p1);
		cada.ajouteParcelle(p2);
		cada.ajouteParcelle(p3);
		cada.ajouteParcelle(p4);
		cada.enregistreProprietaire(p1, propB);
		cada.enregistreProprietaire(p4, propC);
		cada.enregistreProprietaire(p3, propA);
		System.out.println(cada);
		System.out.println("Dans l'exemple p1 a un proprietaire, mais p2 pas");
		System.out.println(cada.chercheProprietaire(p1));
		System.out.println(cada.chercheProprietaire(p2));
		System.out.println("La suppression de p1 n'est pas possible car il a un proprietaire");
		System.out.println(cada.supprimeParcelle(p1));
		System.out.println(cada);
		System.out.println("La suppression de p2 est possible");
		System.out.println(cada.supprimeParcelle(p2));
		System.out.println(cada);
		System.out.println("Exemple de l'enonce apres division de la parcelle p3 en 2");
		cada.diviserParcelle(p3, 2);
		System.out.println(cada);
		System.out.println("A completer a votre guise!");
		
		
	}

}
