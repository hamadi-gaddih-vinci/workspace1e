/**
 * 
 * @author B. Frank
 * 
 */

public class Proprietaire {

	private String nom;
	private String numeroNational;
	
	public Proprietaire(String nom, String numeroNational) {
		if(nom==null||numeroNational==null)
			throw new IllegalArgumentException();
		this.nom = nom;
		this.numeroNational = numeroNational;
	}

	public String getNom() {
		return nom;
	}

	public String getNumeroNational() {
		return numeroNational;
	}

	// Un proprietaire est identifie par son numero national
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((numeroNational == null) ? 0 : numeroNational.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Proprietaire other = (Proprietaire) obj;
		if (numeroNational == null) {
			if (other.numeroNational != null)
				return false;
		} else if (!numeroNational.equals(other.numeroNational))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Proprietaire [nom=" + nom + ", numeroNational=" + numeroNational + "]";
	}
	
}
