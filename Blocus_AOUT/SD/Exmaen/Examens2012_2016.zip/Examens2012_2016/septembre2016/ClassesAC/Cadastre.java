
public class Cadastre {

		// A COMPLETER
	
	public Cadastre() {
		
		// A COMPLETER
	}

	
	// Ajoute une parcelle sans proprietaire
	// renvoie false si la parcelle est deja presente
	public boolean ajouteParcelle(Parcelle parcelle) {
		if(parcelle==null) throw new IllegalArgumentException();
		return false;
		
		// A COMPLETER
	}


	// Enregistre une parcelle comme appartenenat a un proprietraire.
	// Si la parcelle n'est pas encore repertoriee, il faut le faire.
	// s'il y a deja un proprietaire pour la parcelle, ne fait rien et renvoie false.
	public boolean enregistreProprietaire(Parcelle parcelle, Proprietaire proprietaire){
		if(parcelle==null||proprietaire==null) throw new IllegalArgumentException();
		return false;
		
		// A COMPLETER
		
	}


	// Supprime la parcelle 
	// Si la parcelle possede un proprietaire, ne fait rien et renvoie false.
	// Lance une IllegalArgumentException si la parcelle n'est pas repertoriee
	public boolean supprimeParcelle(Parcelle parcelle){
		if(parcelle==null) throw new IllegalArgumentException();
		return false;
		
		// A COMPLETER
		
	}

	// Renvoie le proprietaire de la parcelle
	// Renvoie null si la parcelle n'a pas de proprietaire
	// Lance une IllegalArgumentException si la parcelle n'est pas repertoriee
	public Proprietaire chercheProprietaire(Parcelle parcelle){
		if(parcelle==null) throw new IllegalArgumentException();
		return null;
		
		// A COMPLETER
		
	}

	// Supprime le proprietaire de la parcelle
	// Si la parcelle ne possede pas de proprietaire, ne fait rien et renvoie null.
	// Lance une IllegalArgumentException si la parcelle n'est pas repertoriee
	
	public Proprietaire supprimeProprietaireDeLaParcelle(Parcelle parcelle){
		if(parcelle==null) throw new IllegalArgumentException();
		return null;
		
		// A COMPLETER
		
	}

	// divise la parcelle en k sous-parcelles (10 max)
	// chaque sous-parcelle aura comme identifiant, l'identifiant de la parcelle + une lettre (A, B, ...) 
	// Si la parcelle possede un proprietaire, le proprietaire reste le proprietaire de toutes les sous-parcelles
	// Lance une IllegalArgumentException si la parcelle n'est pas repertoriee
	public void diviserParcelle(Parcelle parcelle, int k){
		if(parcelle==null) throw new IllegalArgumentException();
		if(k<=1)throw new IllegalArgumentException();
		if(k>10)throw new IllegalArgumentException();
		
		// A COMPLETER
		
	}
	
	
	
	// pour les tests! 
	// toString() de l'ensemble + toString() du map
	public String toString(){
		return null;
		
	}
}
