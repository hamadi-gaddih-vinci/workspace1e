public class TestExpressionArithmetique {
  
  public static void main(String[] args) {
    
    ExpressionArithmetiqueSOL ag = new ExpressionArithmetiqueSOL('3');
    ExpressionArithmetiqueSOL ad = new ExpressionArithmetiqueSOL('2');
    ExpressionArithmetiqueSOL a = new ExpressionArithmetiqueSOL('-', ag, ad);
    a = new ExpressionArithmetiqueSOL('~', a, null);
    
    ag = new ExpressionArithmetiqueSOL('9');
    ad = new ExpressionArithmetiqueSOL('3');
    ad = new ExpressionArithmetiqueSOL('/', ag, ad);
    ag = new ExpressionArithmetiqueSOL('4');
    ad = new ExpressionArithmetiqueSOL('*', ag, ad);
    a = new ExpressionArithmetiqueSOL('+', a, ad);
    
    System.out.println("l'expression vaut : " + a.result());
    System.out.println("l'expression est : " + a.notationInfixe());
    System.out.println("l'expression est : " + a.notationPrefixe());
  }
}
