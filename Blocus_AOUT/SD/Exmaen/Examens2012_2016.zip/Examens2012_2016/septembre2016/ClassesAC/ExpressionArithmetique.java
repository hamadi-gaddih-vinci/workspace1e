public class ExpressionArithmetique extends ArbreDeCaracteres {
  
  //*****************************************************************************
  // CONSTRUCTEURS (A NE PAS MODIFIER)
  //*****************************************************************************    
  public ExpressionArithmetique(char e) {
    super(e);
  }

  public ExpressionArithmetique(char e, ExpressionArithmetique g, ExpressionArithmetique d) {
    super(e, g, d);
  }
  
  public ExpressionArithmetique filsGauche() {
    return (ExpressionArithmetique) super.filsGauche();
  }
  
  public ExpressionArithmetique filsDroit() {
    return (ExpressionArithmetique) super.filsDroit();
  }

  //*****************************************************************************
  // METHODES PUBLIQUES (A MODIFIER)
  //*****************************************************************************    
  public double result() {
  }
  
  public String notationInfixe() {
  }
  
  public String notationPrefixe() {
  }
}
