
public class Parcelle {

	private String numeroParcelle;

	public Parcelle(String numeroParcelle) {
		super();
		this.numeroParcelle = numeroParcelle;
	}

	public String getNumeroParcelle() {
		return numeroParcelle;
	}

	@Override
	public String toString() {
		return "Parcelle [numeroParcelle=" + numeroParcelle + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((numeroParcelle == null) ? 0 : numeroParcelle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Parcelle other = (Parcelle) obj;
		if (numeroParcelle == null) {
			if (other.numeroParcelle != null)
				return false;
		} else if (!numeroParcelle.equals(other.numeroParcelle))
			return false;
		return true;
	}
	
	

	
}
