public class ArbreDeCaracteres {
  
  private NoeudExpression racine;
  
  //*****************************************************************************
  // CONSTRUCTEURS
  //*****************************************************************************  
  public ArbreDeCaracteres() {
    this.racine = null;
  }
  
  public ArbreDeCaracteres(char e) {
    this.racine = new NoeudExpression(e);
  }

  public ArbreDeCaracteres(char e, ArbreDeCaracteres g, ArbreDeCaracteres d) {
    this.racine = new NoeudExpression(e, g, d);
  }
  
  //*****************************************************************************
  // METHODES PUBLIQUES
  //*****************************************************************************  
  public boolean estVide() {
    return this.racine == null;
  }
    
  public ArbreDeCaracteres filsGauche() {
    return this.racine.sousArbreGauche;
    
  }
  
  public ArbreDeCaracteres filsDroit() {
    return this.racine.sousArbreDroit;    
  }
  
  public char element() {
    return this.racine.element;    
  }

  //*****************************************************************************
  // METHODES ET CLASSE PRIVEES
  //*****************************************************************************  

  public NoeudExpression racine() {
    return racine;
  }

  public class NoeudExpression {
    
    private char element; // operateur si noeud, chiffre si feuille
    private ArbreDeCaracteres sousArbreGauche;
    private ArbreDeCaracteres sousArbreDroit;
    
    private NoeudExpression(char element) {
      this.element = element;
      this.sousArbreGauche = new ArbreDeCaracteres();
      this.sousArbreDroit = new ArbreDeCaracteres();
    }
    
    private NoeudExpression(char element, ArbreDeCaracteres sousArbreGauche,
        ArbreDeCaracteres sousArbreDroit) {
      this.element = element;
      this.sousArbreGauche = sousArbreGauche;
      this.sousArbreDroit = sousArbreDroit;
      
    }
    
    public char element() {
      return element;
    }
    
  }
  
}