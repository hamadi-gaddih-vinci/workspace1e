import java.util.HashMap;

/**
 * Implementation de l'interface Liste avec une liste doublement chainee et sentinelles
 * Cette implementation refuse les doublons
 * 
 * @author 
 * 
 */

public class ListeImpl implements Liste {

	private Noeud tete, queue;
	private int taille;
	private HashMap<Object, Noeud> mapObjetNoeud; // permet de retrouver directement le noeud qui contient l'element
												  // ce map est cree et rempli dans le constructeur utilise pour les tests


	public ListeImpl() {
		mapObjetNoeud = new HashMap<Object, Noeud>();
		tete = new Noeud();  // sentinelle de tete
		queue = new Noeud();  // sentinelle de queue
		tete.suivant = queue;
		queue.precedent = tete;
		taille=0;
	}

	// A NE PAS MODIFIER --> POUR LES TESTS!!!
	public ListeImpl(Object[] table) {
		if(table == null)
			throw new IllegalArgumentException();
		mapObjetNoeud = new HashMap<Object, Noeud>();
		this.taille = table.length;
		tete = new Noeud();
		queue = new Noeud();  
		tete.suivant = queue;
		queue.precedent = tete;
		for (int i = table.length-1; i>=0; i--) {
			if(mapObjetNoeud.containsKey(table[i]))
				throw new IllegalArgumentException(); 	// refus de doublons
			Noeud nouveauNoeud = new Noeud(this.tete,table[i],this.tete.suivant);
			mapObjetNoeud.put(table[i], nouveauNoeud);
			this.tete.suivant.precedent=nouveauNoeud;
			this.tete.suivant=nouveauNoeud;
		}	
	}

	public int taille(){
		return taille;
	}

	public boolean estVide(){
		return taille==0;
	}

	// A ne pas modifier ! Methode utilisee pour les tests
	public boolean equals(ListeImpl l){
		if(taille!=l.taille)
			return false;
		Noeud baladeurThis = tete.suivant;
		Noeud baladeurL = l.tete.suivant;
		while(baladeurThis!=queue){
			if(!baladeurL.element.equals(baladeurThis.element))
				return false;
			baladeurL = baladeurL.suivant;
			baladeurThis = baladeurThis.suivant;
		}
		baladeurThis = queue.precedent;
		baladeurL = l.queue.precedent;		
		while(baladeurThis!=tete){
			if(!baladeurL.element.equals(baladeurThis.element))
				return false;
			baladeurL = baladeurL.precedent;
			baladeurThis = baladeurThis.precedent;
		}
		return true;
	}



	/**
	 * Cette methode recherche le noeud qui contient la premiere occurrence de l'element passe en parametre
	 * @param element l'element recherche
	 * @return le noeud recherche ou null si l'element n'est pas present dans la liste
	 */
	private Noeud trouverNoeud(Object element) {


		// A COMPLETER
		// Pensez a utiliser le map mapObjetNoeud!

		return null;
		
	}

	/**
	 * Cette methode permute la valeur du noeud passe en parametre avec la valeur du noeud precedent
	 * Cette methode ne doit pas tester la presence du noeud dans la liste
	 * Cette methode renvoie false si le noeud est le "premier" noeud de la cha�ne 
	 * @param noeud 
	 */
	private boolean permuterAvantValeur(Noeud noeud) {

		// A COMPLETER
		// ATTENTION CE SONT LES VALEURS QUI SONT PERMUTEES! IL EST INUTILE DE PERMUTER LES NOEUDS!!!
		return false;
		
	}



	/**
	 * Cette methode permute l'element passe en parametre avec l'element du noeud precedent
	 * @param element l'element a permuter avec son precedent
	 * @return true si l'element a pu etre permute, false sinon
	 */
	public boolean permuterAvant(Object element) {	

		// A COMPLETER
		// cette methode utilise les methodes trouverNoeud() et permuterAvantValeur()
		// cette methode doit mettre a jour le mapObjetNoeud! Les elements permutes ont change de noeud

		return false;
		

	}

	/**
	 * Cette methode supprime le noeud passe en parametre
	 * Cette methode ne doit pas tester la presence du noeud dans la liste
	 * @param noeud
	 */
	private void supprimerNoeud (Noeud noeud){
		
		// A COMPLETER
		
	}

	
	/**
	 * Cette methode supprime l'element passe en parametre
	 * @param element l'element a supprimer
	 * @return true si l'element a a pu etre supprime, false sinon
	 */
	public boolean supprimer(Object element) {

		// A COMPLETER
		// cette methode utilise les methodes trouverNoeud() et supprimerNoeud()
		// cette methode doit mettre a jour le mapObjetNoeud! L'element ne se trouve plus dans un noeud de la liste!
		return false;
		
	}


	public String toString(){
		
		
		// A COMPLETER
		// Les elements doivent appara�tre numerotes
		// Exemple :
		// 1 : objet1
		// 2 : objet2
		// ...
		
		return null;
		
	}
	
	
	
	private class Noeud {
		private Object element;
		private Noeud suivant;
		private Noeud precedent;

		private Noeud() {
			this(null, null, null);
		}

		private Noeud(Object element) {
			this(null, element, null);
		}

		private Noeud(Noeud precedent, Object element, Noeud suivant) {
			this.element = element;
			this.suivant = suivant;
			this.precedent = precedent;
		}

		public Object element() {
			return element;
		}
	}

}