import java.util.HashSet;

public class ListeDoubleAvecSentinelles {
	protected int taille;
	protected Noeud tete, queue;
	// N'ajoutez pas d'autres attributs
	
	public ListeDoubleAvecSentinelles(){
		taille=0;
		tete = new Noeud(null);
		queue = new Noeud(null);
		tete.suivant = queue;
		queue.precedent = tete; 
	}
	
	public int taille(){
		return taille;
	}

	public boolean estVide(){
		return taille==0;
	}
	
	public void insererEnTete(Object element){
		taille++;
		Noeud nn = new Noeud(element);
		nn.suivant = tete.suivant;
		nn.precedent = tete;
		nn.suivant.precedent = nn;
		nn.precedent.suivant = nn;
	}
	
	/**
	 * Verifie si la liste courante contient les memes elements que l'autreListe
	 * Les elements doivent apparaitre dans le meme ordre.
	 * 
	 * @return true si les listes egales, false sinon
	 */
	public boolean equals(ListeDoubleAvecSentinelles autreListe){
	  //A COMPLETER
	  throw new UnsupportedOperationException("La m�thode n'est pas encore constuite");
   }
	 	
	/**
	 * Renvoie le premier noeud de la liste qui contient l'element passe en parametre.
	 * 
	 * @return le noeud contenant l'element, null si l'element n'est pas present dans la liste
	 */
	private Noeud trouverNoeud (Object element){
	  //A COMPLETER
	  throw new UnsupportedOperationException("La m�thode n'est pas encore constuite");
	}
	
	/**
	 * Verifie la presence d'un element dans la liste.
	 * 
	 * @return true si l'element est present, false sinon
	 */
	public boolean contient(Object element){
	  //A COMPLETER
	  throw new UnsupportedOperationException("La m�thode n'est pas encore constuite");
	}
	
	/**
	 * Supprime le noeud passe en parametre.
	 * (il ne faut pas verifier si le noeud appartient bien a la liste)
	 */	
	private void supprimerNoeud(Noeud noeud) {
	  //A COMPLETER
	  throw new UnsupportedOperationException("La m�thode n'est pas encore constuite");
	}
	
	/**
	 * Supprime la premiere occurrence de l'element dans la liste.
    *
	 * @return true si l'element a ete supprime, false sinon
	 */
	public boolean supprimer(Object element){
	  //A COMPLETER
	  throw new UnsupportedOperationException("La m�thode n'est pas encore constuite");
	}
	
	/**
	 * Verifie la presence d'ex-aequos dans la liste.
	 *
	 * @return true si la liste contient des ex-aequos, false sinon
	 */
	public boolean contientExAequos(){
	  //A COMPLETER
	  throw new UnsupportedOperationException("La m�thode n'est pas encore constuite");
	}

	class Noeud{
		Object element;
		Noeud suivant;
		Noeud precedent;
		
		public Noeud(Object element) {
			this.element = element;
		}
		
		public Noeud(Object element, Noeud suivant, Noeud precedent) {
			this.element = element;
			this.suivant = suivant;
			this.precedent = precedent;
		}
	}
}