import java.util.HashSet;

public class ListeDoubleAvecSentinelles {
	protected int taille;
	protected Noeud tete, queue;
	// N'ajoutez pas d'autres attributs
	
	public ListeDoubleAvecSentinelles(){
		taille=0;
		tete = new Noeud(null);
		queue = new Noeud(null);
		tete.suivant = queue;
		queue.precedent = tete; 
	}
	
	public int taille(){
		return taille;
	}

	public boolean estVide(){
		return taille==0;
	}
	
	public void insererEnTete(Object element){
		taille++;
		Noeud nn = new Noeud(element);
		nn.suivant = tete.suivant;
		nn.precedent = tete;
		nn.suivant.precedent = nn;
		nn.precedent.suivant = nn;
	}
	
	/**
	 * verifie si la liste courante contient les memes elements que l'autreListe
	 * Les elements doivent apparaitre dans le meme ordre
	 * @param autreListe
	 * @return true si les listes egales, false sinon
	 */
	public boolean equals(ListeDoubleAvecSentinelles autreListe){
		if (autreListe == null) {
		 return false;
		} 
		// A COMPLETER
		return false;
   }
	 	
	/**
	 * renvoie le premier noeud de la liste qui contient l'element passe en parametre
	 * @param element 
	 * @return le noeud contenant l'element, null si l'element n'est pas present dans la liste
	 */
	private Noeud trouverNoeud (Object element){
		// A COMPLETER
		return null;
	}
	
	/**
	 * verifie la presence d'un element dans la liste
	 * @param element
	 * @return true si l'element est present, false sinon
	 */
	public boolean contient(Object element){
		// A COMPLETER
		return false;
	}
	
	/**
	 * supprime le noeud passe en parametre
	 * (il ne faut pas verifier si le noeud appartient bien a la liste)
	 * @param noeud
	 */	
	private void supprimerNoeud(Noeud noeud){
		// A COMPLETER
	}
	
	/**
	 * supprime la premiere occurrence de l'element dans la liste
	 * @param element
	 * @return true si l'element a ete supprime, false sinon
	 */
	public boolean supprimer(Object element){
	   // A COMPLETER
		return false;
	}
	
	/**
	 * verifie la presence d'ex-aequos dans la liste
	 * @return true si la liste contient des ex-aequos, false sinon
	 */
	public boolean contientExAequos(){
		// A COMPLETER
		// Utilisez un objet de la classe HashSet pour l'ensemble (cfr enonce)
		return false; 	   
	}

	class Noeud{
		Object element;
		Noeud suivant;
		Noeud precedent;
		
		public Noeud(Object element) {
			this.element = element;
		}
		
		public Noeud(Object element, Noeud suivant, Noeud precedent) {
			this.element = element;
			this.suivant = suivant;
			this.precedent = precedent;
		}

	}
}