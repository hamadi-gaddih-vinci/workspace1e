

public class EquipeGuerriers {

	// A COMPLETER
	
	public EquipeGuerriers(int nombreGuerriers, int pointsDeVie) {
		// A COMPLETER
	}
	
	public int nombreGuerriersEnVie(){
		// A COMPLETER
		return -1;
	}
	
	public Guerrier jouer(int pointsDeViePerdus){
		// A COMPLETER
		return null;
	}
	
	public Guerrier getGuerrier(int numero){
		// A COMPLETER
		return null;
	}
	
}
