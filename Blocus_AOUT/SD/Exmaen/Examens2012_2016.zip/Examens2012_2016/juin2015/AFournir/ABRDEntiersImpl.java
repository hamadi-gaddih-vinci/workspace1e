
public class ABRDEntiersImpl {
	
	private NoeudEntier racine;
	private int taille;
	
	public ABRDEntiersImpl() {
		this.racine=null ;
		taille = 0;
	}
	
	public void insere(int entier){
		if(this.estVide()) {
			this.racine = new NoeudEntier(entier);
			taille ++;
			return;
		}
		if(entier<this.racine.element())this.filsGauche().insere(entier);
		else this.filsDroit().insere(entier);
		taille ++;
		
	}
	
	public int taille(){
		return taille;
	}
	
	/**
	 * Uniquement pour les tests, NE PAS MODIFIER
	 * @param numeroTest numero de l'arbre de test:
	 * 0 : arbre vide
	 * autre: arbre de l'enonce
	 */
	public ABRDEntiersImpl(int numeroTest) {
		if (numeroTest == 0){
			// arbre vide
			this.racine=null ;
			return;
		}
		
		// Arbre de l'enonce
		ABRDEntiersImpl d = new ABRDEntiersImpl();
		d.racine = new NoeudEntier(11);
		ABRDEntiersImpl g = new ABRDEntiersImpl();
		ABRDEntiersImpl r = new ABRDEntiersImpl();
		r.racine = new NoeudEntier(g, 9, d);
		
		g = r;
		d = new ABRDEntiersImpl();
		r = new ABRDEntiersImpl();
		r.racine = new NoeudEntier(g, 12, d);
		
		ABRDEntiersImpl d2 = r;
		
		g = new ABRDEntiersImpl();
		g.racine = new NoeudEntier(5);		
		d = new ABRDEntiersImpl();
		d.racine = new NoeudEntier(7);		
		r = new ABRDEntiersImpl();
		r.racine = new NoeudEntier(g, 6, d);
		
		d=r;
		g = new ABRDEntiersImpl();
		g.racine = new NoeudEntier(2);	
		r = new ABRDEntiersImpl();
		r.racine = new NoeudEntier(g, 4, d);
		
		g=r;
		this.racine = new NoeudEntier(g, 8, d2);
	}
	
	public NoeudEntier racine(){
		return racine;
	}
	
	public boolean estVide(){
		return  this.racine == null;
	}

	public ABRDEntiersImpl filsGauche(){
		return this.racine.sousArbreGauche;
		
	}
	
	public ABRDEntiersImpl filsDroit(){
		return this.racine.sousArbreDroit;	
	}

	
	public class NoeudEntier {
		private int entier; 
		private ABRDEntiersImpl sousArbreGauche;
		private ABRDEntiersImpl sousArbreDroit;

		private NoeudEntier(int entier){
			this.entier = entier;
			this.sousArbreGauche = new ABRDEntiersImpl();
			this.sousArbreDroit = new ABRDEntiersImpl();
		}
		
		private NoeudEntier(ABRDEntiersImpl g,int entier,ABRDEntiersImpl d){
			this.entier = entier;
			this.sousArbreGauche = g;
			this.sousArbreDroit = d;
		}
		
		public int element() {
			return entier;
		}
		
	}

}
