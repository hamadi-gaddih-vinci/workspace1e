public class TestListeDoubleAvecSentinelles {
  public static void main(String args[]) {
    int max = 500;
    Elt[] elts = new Elt[max];
	 int i = 0;
	 while(i != max) {
	   elts[i] = new Elt(i);
	   i++;
	 }
	 
	 
    ListeDoubleAvecSentinelles l1 = t1(elts);
	 t2(elts, l1);
	 t3(elts);
	 t4(elts, l1);
	 t5(elts);
  }
  
  //TEST DE LA METHODE insererEnTete
  private static ListeDoubleAvecSentinelles t1(Elt[] elts) {
    ListeDoubleAvecSentinelles res = new ListeDoubleAvecSentinelles();
    int i = 0;
	 
	 
	 while(i != elts.length) {
      res.insererEnTete(elts[i]);
		i++;
		assertEquals("Apr�s avoir ins�r� un nouvel �l�ment en t�te de la liste, la taille de celle-ci n'est pas correcte", i, res.taille());
		
		int nbr = count(i + 3, res);
		assertEquals("Apr�s avoir ins�r� un nouvel �l�ment en t�te de la liste, votre liste ne contient pas le bon nombre de noeud", i + 2, nbr);
		
		isCorrect("Apr�s avoir ins�r� un nouvel �l�ment en t�te de la liste,votre liste n'est pas correctement construite", elts, res, i);
	 }
	 
	 return res;
  }
  
  //TEST DE LA METHODE equals
  private static void t2(Elt[] elts, ListeDoubleAvecSentinelles l1) {
    String msg = "Votre methode equals n'est pas correcte";
    
	 ListeDoubleAvecSentinelles l2 = new ListeDoubleAvecSentinelles();
    int i = 0;
	 
	 while(i != elts.length) {
		assertEquals(msg, l2.equals(l1), false);
		assertEquals(msg, l1.equals(l2), false);
      l2.insererEnTete(elts[i]);
		i++;
	 }
	 
	 assertEquals(msg, l2.equals(l1), true);
	 assertEquals(msg, l1.equals(l2), true);
	 
	 i = 0;
	 while(i != elts.length) {
      l2.insererEnTete(elts[i]);
		assertEquals(msg, l2.equals(l1), false);
		assertEquals(msg, l1.equals(l2), false);
		i++;
	 }
	 
	 ListeDoubleAvecSentinelles e1 = new ListeDoubleAvecSentinelles();
	 ListeDoubleAvecSentinelles e2 = new ListeDoubleAvecSentinelles();
	 assertEquals(msg, e1.equals(e2), true);
  }
  
  //TEST DE LA METHODE contient
  private static void t3(Elt[] elts) {
    String msg = "Soit votre methode contient n'est pas correcte, ";
	 msg += "soit votre m�thode equals n'est pas correcte.";

	 Elt elt = new Elt(-789);
	 ListeDoubleAvecSentinelles l1 = new ListeDoubleAvecSentinelles();
	 ListeDoubleAvecSentinelles l2 = new ListeDoubleAvecSentinelles();
	 assertEquals(msg, l1.contient(elt), false);
	 assertEquals(msg, l1.equals(l2), true);
	 assertEquals(msg, l2.equals(l1), true);

    int i = 0;	 
	 while(i != elts.length) {
      l1.insererEnTete(elts[i]);
      l2.insererEnTete(elts[i]);
	   assertEquals(msg, l1.contient(elt), false);
	   assertEquals(msg, l1.equals(l2), true);
	   assertEquals(msg, l2.equals(l1), true);
		i++;
	 }
	 
    l1.insererEnTete(elt);
    l2.insererEnTete(elt);
	 assertEquals(msg, l1.contient(elt), true);
	 assertEquals(msg, l1.equals(l2), true);
	 assertEquals(msg, l2.equals(l1), true);
	 
	 i = 0;
	 while(i != elts.length) {
      l1.insererEnTete(elts[i]);
      l2.insererEnTete(elts[i]);
	   assertEquals(msg, l1.contient(elt), true);
	   assertEquals(msg, l1.equals(l2), true);
	   assertEquals(msg, l2.equals(l1), true);
		i++;
	 }
  }
  
  //TEST DE LA METHODE supprimer
  private static void t4(Elt[] elts, ListeDoubleAvecSentinelles l) {
    String msg = "Votre methode supprimer n'est pas correcte";
	 
	 // step doit �tre un nombre premier
    int step = 7;
	 boolean[] supp = new boolean[elts.length];
	 
	 Elt e = new Elt(-789);
	 assertEquals(msg, l.supprimer(e), false);
	 assertEquals(msg, count(elts.length + 3, l), elts.length + 2);
    isCorrect(msg, elts, supp, l);

	 int i = 0;
	 int n = 0;
	 while(n != elts.length) {
		n++; 
	   supp[i] = true;
	   assertEquals(msg, l.supprimer(elts[i]), true);
	   assertEquals(msg, l.supprimer(e), false);
	   assertEquals(msg, count(elts.length - n + 3, l), elts.length - n + 2);
		isCorrect(msg, elts, supp, l);
	   i = (i + step) % elts.length;
	 }
	 
	 assertEquals(msg, l.supprimer(e), false);
	 assertEquals(msg, count(3, l), 2);
    isCorrect(msg, elts, supp, l);
  }
  
  //TEST DE LA METHODE contientExAequos
  private static void t5(Elt[] elts) {
    String msg = "Soit votre methode contientExAequos n'est pas correcte, ";
	 msg += "soit votre m�thode equals n'est pas correcte.";
	 
	 ListeDoubleAvecSentinelles l1 = new ListeDoubleAvecSentinelles();
	 ListeDoubleAvecSentinelles l2 = new ListeDoubleAvecSentinelles();
	 assertEquals(msg, l2.contientExAequos(), false);
	 assertEquals(msg, l1.equals(l2), true);
	 assertEquals(msg, l2.equals(l1), true);
	 
	 int i = 0;
	 while(i != elts.length) {
	   l1.insererEnTete(elts[i]);
		l2.insererEnTete(elts[i]);
	   assertEquals(msg, l2.contientExAequos(), false);
	   assertEquals(msg, l1.equals(l2), true);
	   assertEquals(msg, l2.equals(l1), true);
      i++;
	 }
	 
	 i = 0;
	 while(i != 3) {
	   int j = 0;
	   while(j != elts.length) {
	     l1.insererEnTete(elts[i]);
		  l2.insererEnTete(elts[i]);
	     assertEquals(msg, l2.contientExAequos(), true);
	     assertEquals(msg, l1.equals(l2), true);
	     assertEquals(msg, l2.equals(l1), true);
        j++;
		}
		i++;
	 }
  }

  private static int isCorrect(String msg, Elt[] elts, boolean b[], ListeDoubleAvecSentinelles l) {
    int i = 0;
	 ListeDoubleAvecSentinelles.Noeud current = l.tete;
	 
	 while(i != elts.length) {
	   i++;
		if (!b[elts.length - i]) { 
	     current = current.suivant;
		  assertEquals(msg, current.element, elts[elts.length - i]);
		}
	 }
	 
	 return i;
  }

    
  private static int isCorrect(String msg, Elt[] elts, ListeDoubleAvecSentinelles l, int n) {
    int i = 0;
	 ListeDoubleAvecSentinelles.Noeud current = l.tete;
	 
	 while(i != n) {
	   current = current.suivant;
	   i++;
		assertEquals(msg, current.element, elts[n -i]);
	 }
	 
	 return i;
  }

  private static int count(int max, ListeDoubleAvecSentinelles l) {
    int i = 0;
	 ListeDoubleAvecSentinelles.Noeud current = l.tete;
	 
	 while(i != max && current != null) {
	   current = current.suivant;
	   i++;
	 }
	 
	 return i;
  }

  private static void assertEquals(String msg, boolean b1, boolean b2) {
    if (b1 != b2) {
	   System.err.println(msg);
	   System.exit(-1);
	 }
  }
  
  private static void assertEquals(String msg, Object o1, Object o2) {
    if (o1 != o2) {
	   System.err.println(msg);
	   System.exit(-1);
	 }
  }
 
  private static void assertEquals(String msg, int n1, int n2) {
    if (n1 != n2) {
	   System.err.println(msg);
	   System.exit(-1);
	 }
  }
  
  private static class Elt {
    private int n;
	 
	 private Elt(int n) {
	   this.n = n;
	 }
	 
	 public String toString() {
	   return "" + n;
	 }
	 
    public boolean equals(Object o) {
	   return ((Elt) o).n == n;
	 }
  }
}