
public class TestKemeV2 {

	public static int keme(ABRDEntiersImpl a, int k){
		if(a==null)
			throw new IllegalArgumentException();
		if(k<1)
			throw new IllegalArgumentException();
		if(k>a.taille())
			throw new IllegalArgumentException();	
		return kemeInterne(a, k);	
	}


	private static int kemeInterne(ABRDEntiersImpl a, int k){
		// A COMPLETER
		return -1;
	}

	public static ABRDEntiersImpl arbreEnonce(){
		ABRDEntiersImpl a = new ABRDEntiersImpl();
		a.insere(8);
		a.insere(4);
		a.insere(2);
		a.insere(6);
		a.insere(5);
		a.insere(7);
		a.insere(12);
		a.insere(9);
		a.insere(11);
		return a;
	}

	public static ABRDEntiersImpl arbreVide(){
		return new ABRDEntiersImpl();
	}

	public static void main(String[] args) {

		ABRDEntiersImpl a = arbreEnonce();
		int keme = keme(a, 6);
		if (keme != 8)
			System.out.println("Probleme: Le 6eme = 8, ta methode donne" + keme);

		keme = keme(a, 4);
		if (keme != 6)
			System.out.println("Probleme: Le 4eme = 6, ta methode donne" + keme);

		keme = keme(a, 9);
		if (keme != 12)
			System.out.println("Probleme: Le 9eme = 12, ta methode donne" + keme );

		try{
			keme = keme(a, 10);
		}catch (IllegalArgumentException e){

		}

		try{
			keme = keme(a, -5);
		}catch (IllegalArgumentException e){

		}
		System.out.println("Fin des tests");


	}
}
