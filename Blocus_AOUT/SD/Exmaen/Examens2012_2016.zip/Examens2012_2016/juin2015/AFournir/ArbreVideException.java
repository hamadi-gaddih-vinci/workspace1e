
public class ArbreVideException extends Exception {

	public ArbreVideException() {
		super();
	}

	public ArbreVideException(String message) {
		super(message);
	}

}
