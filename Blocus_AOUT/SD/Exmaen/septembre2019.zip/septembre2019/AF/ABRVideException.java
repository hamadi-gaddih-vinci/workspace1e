
    public class ABRVideException extends RuntimeException {
   
       public ABRVideException() {
         super();
      }
   
       public ABRVideException(String s) {
         super(s);
      }
   
   }