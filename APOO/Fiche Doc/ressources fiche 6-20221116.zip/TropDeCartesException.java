public class TropDeCartesException extends RuntimeException {
    public TropDeCartesException() {
    }

    public TropDeCartesException(String message) {
        super(message);
    }
}
